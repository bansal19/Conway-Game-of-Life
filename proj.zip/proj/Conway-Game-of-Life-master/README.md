Conway Game of Life

To read more regarding this game, please check out: https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life
